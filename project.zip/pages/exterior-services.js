// pages/ExteriorServices.js
const ExteriorServices = () => {
    return (
      <div>
        <h1>Exterior Services</h1>
        <p>Description of exterior services.</p>
      </div>
    );
  };
  
  export default ExteriorServices;
  